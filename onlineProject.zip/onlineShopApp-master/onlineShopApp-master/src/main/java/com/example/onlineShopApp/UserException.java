package com.example.onlineShopApp;

public class UserException extends Exception{
    public UserException(String message){
        super(message);
    }
}
