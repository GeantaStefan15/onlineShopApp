package com.example.onlineShopApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShopAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineShopAppApplication.class, args);
	}

}
