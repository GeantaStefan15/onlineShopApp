package com.example.onlineShopApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShopAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
